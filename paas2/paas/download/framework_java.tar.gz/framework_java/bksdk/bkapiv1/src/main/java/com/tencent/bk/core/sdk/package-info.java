/*
 *  Copyright (c) 2017.  Tencent 蓝鲸智云(BlueKing)
 */

/**
 * cmdb包 为配置平台的SDK
 * job包 为作业平台的SDK
 * paas包 为paas平台的SDK
 * msg包 为通知消息的SDK
 */
package com.tencent.bk.core.sdk;
package com.tencent.bk.core.sdk.protocol;

public interface IResp <T> {
}

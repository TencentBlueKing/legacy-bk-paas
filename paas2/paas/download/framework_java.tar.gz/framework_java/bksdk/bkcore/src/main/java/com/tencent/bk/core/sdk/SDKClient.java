/*
 * Copyright (c) 2017. Tencent BlueKing
 */

package com.tencent.bk.core.sdk;

/**
 *
 */
public interface SDKClient {

}

/*
 *  Copyright (c) 2017.  Tencent 蓝鲸智云(BlueKing)
 */

package com.tencent.examples.service;

/**
 * 演示
 */
public interface DemoService {

    String getDemo();
}


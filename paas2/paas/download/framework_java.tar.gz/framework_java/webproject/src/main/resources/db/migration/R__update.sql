-- 通过修改内容可重复执行的脚本，记住不要打版本号，否则会和Versoned一样，不能进行修改内容来达到重复执行
-- insert into demo (name) values('v3v');
-- insert into demo (name) values('33c3');
-- insert into demo (name) values('13f1');
select sysdate();
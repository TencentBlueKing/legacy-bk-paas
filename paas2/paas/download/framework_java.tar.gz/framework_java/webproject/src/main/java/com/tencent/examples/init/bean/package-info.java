/*
 *  Copyright (c) 2017 . Tencent 蓝鲸智云(BlueKing)
 */

/**
 * 在init/bean这个包下可以创建做一些需要加载的Bean类定义 通过@Configuration初始化
 */
package com.tencent.examples.init.bean;
package com.tencent.examples.demo.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChartC {
    private String category;
    private Integer value;


}

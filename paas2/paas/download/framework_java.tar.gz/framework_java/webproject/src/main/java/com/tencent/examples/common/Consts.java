/*
 *  Copyright (c) 2017.  Tencent 蓝鲸智云(BlueKing)
 */

package com.tencent.examples.common;

/**
 *
 */
public class Consts {

    public static final int SYS_UNKNOW_ERR = 9999999;
}

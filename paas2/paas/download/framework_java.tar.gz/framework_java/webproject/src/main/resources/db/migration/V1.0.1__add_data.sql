SET NAMES UTF8;

INSERT INTO `user` (`username`, `phone`, `email`) VALUES ('sam', '13800138004', 'sam@@bk.com');
INSERT INTO `user` (`username`, `phone`, `email`) VALUES ('jack', '13800138005', 'jack@bk.com');

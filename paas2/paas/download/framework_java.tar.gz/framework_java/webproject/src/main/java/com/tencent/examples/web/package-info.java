/*
 *  Copyright (c) 2017.  Tencent 蓝鲸智云(BlueKing)
 */

/**
 *  filter包演示了定义Filter
 *  page包包含了一些定义了页面View跳转的Controller
 *  rest包包含了一些定义了数据接口的RestController
 *  support包包含了接口统一异常处理的类
 */
package com.tencent.examples.web;
# -*- coding: utf-8 -*-
"""
Copyright © 2012-2017 Tencent BlueKing. All Rights Reserved. 蓝鲸智云 版权所有
"""
from esb.utils import SmartHost


# The system name in lowercase shall be the same as the system package name
SYSTEM_NAME = 'HCP'

host = SmartHost(
    # The domain name of system production environment shall be filled in
    host_prod='hcp.domain.com',
)

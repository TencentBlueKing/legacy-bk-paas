# -*- coding: utf-8 -*-

from django.conf.urls import url

from account import views

urlpatterns = [
    url(r'^logout/$', views.logout, name='logout'),
]

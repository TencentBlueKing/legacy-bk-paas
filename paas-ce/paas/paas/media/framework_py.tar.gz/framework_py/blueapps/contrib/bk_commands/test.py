# -*- coding: utf-8 -*-
"""
@author: 蓝鲸
@created: 2017/6/14
@desc:
"""
import sys

from blueapps.contrib.bk_commands import bk_admin

bk_admin(sys.argv)
